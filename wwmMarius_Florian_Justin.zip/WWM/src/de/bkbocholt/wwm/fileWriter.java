package de.bkbocholt.wwm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Scanner;

public class fileWriter
{
	String filename;

	public fileWriter(String filename)
	{
		this.filename = filename;
	}

	/*
	 * public void schreibeInDatei(String eingabe) { Path p = Path.of(filename); try
	 * { Path filePath = Files.writeString(p, eingabe); String s =
	 * Files.readString(filePath); } catch (IOException e) { e.printStackTrace(); }
	 * }
	 */

	//https://www.w3schools.com/java/java_files_create.asp
	
	public void schreibeInDatei(String eingabe)
	{
		try
		{
			FileWriter myWriter = new FileWriter(filename);
			myWriter.write(eingabe);
			myWriter.close();
			System.out.println("Successfully wrote to the file.");
		} catch (IOException e)
		{
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

	/*
	 * public ArrayList<String> leseZeilenweiseAusDatei() { Path file =
	 * FileSystems.getDefault().getPath(filename); ArrayList<String> ausgabe = new
	 * ArrayList<>(); try { InputStream in = Files.newInputStream(file);
	 * BufferedReader reader = new BufferedReader(new InputStreamReader(in)); String
	 * line = null; while ((line = reader.readLine()) != null) { ausgabe.add(line);
	 * } reader.close(); } catch (IOException e) { e.printStackTrace(); } return
	 * ausgabe; }
	 */

	//https://www.w3schools.com/java/java_files_read.asp
	
	public ArrayList<String> leseZeilenweiseAusDatei()
	{
		ArrayList<String> ausgabe = new ArrayList<>();
		try
		{
			File myObj = new File(filename);
			Scanner myReader = new Scanner(myObj);
			while (myReader.hasNextLine())
			{
				String data = myReader.nextLine();
				ausgabe.add(data);
			}
			myReader.close();
		} catch (FileNotFoundException e)
		{
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
		
		return ausgabe;
	}
}
